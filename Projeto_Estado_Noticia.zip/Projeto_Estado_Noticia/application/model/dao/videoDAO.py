from application.model.entity.video import Video
from flask import current_app

class VideoDAO:
    
    def __init__(self):
        self._videos = []
        self._videos.append(Video(1, "Rio de Janeiro", "Decisão foi unânime. Ação pode levar à perda do mandato do vereador e ex-PM. Parlamentar é acusado por ex-funcionários de importunação sexual, assédios moral e sexual e agressões. Ele também é acusado de estupro e de forjar vídeos para postar em suas redes sociais. Ele nega todas as acusações. ", "/videos/thumbs/noticiaRJI.jpg",'videos/noticiaRJV.mp4',1,"05/04/2022"))
        self._videos.append(Video(2, "Minas Gerais:", "Governo espera desobrigar uso em todo o estado no dia 1º de maio, mas secretário de Saúde diz que já existem cidades aptas a liberar as máscaras neste momento, entre elas, Belo Horizonte. Decisão final cabe às prefeituras.", "/videos/thumbs/noticiaMGI.jpg","videos/noticiaMGV.mp4",2,"05/04/2022"))
        self._videos.append(Video(3, "Espirito Santo:", "Oportunidades disponíveis para estudantes dos ensinos médio, técnico e superior.", "/videos/thumbs/noticiaESI.jpg","videos/noticiaESV.mp4",1,"5/04/2022"))
       
    def getVideoPorId(self, id):
        video = None
        for index, item in enumerate(self.getVideos()):
            if item.getId() == id:
                video = item
                return video
        return video

    def getVideos(self):
        return self._videos

    def getVideosMaisCurtidos(self):
        videos = current_app.config['videos']
        mais_curtidos = sorted(videos.getVideos(), key=lambda x: x.getCurtidas(), reverse=True)
        return mais_curtidos