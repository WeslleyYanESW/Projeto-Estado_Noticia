class CategoriaDAO():
    def __init__(self):
        
        self._categorias= []
        self._categorias.append(Categoria(1, "Rio de Janeiro", "Conselho da Camara do Rio abre processo etico-disciplinar contra Gabriel Monteiro","/categorias/noticiaRJ.jpg"))
        self._categorias.append(Categoria(2, "Minas Gerais", "Assista os melhores lances da NBA","/categorias/noticiaMG.jpg"))
        self._categorias.append(Categoria(3, "Espirito Santo", "Estagio no ES: veja como concorrer a 120 vagas disponiveis com bolsas de R$ 450 a R$ 1 mil","/categorias/noticiaES.jpg"))
    
    def getCategorias(self):
        return self._categorias

    def getCategoriaPorId(self, id):
        categoria = None
        for index, item in enumerate(self.getCategorias()):
            if item.getId() == id:
                categoria = item
                return categoria
        return categoria